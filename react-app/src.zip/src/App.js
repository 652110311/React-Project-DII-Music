import React, { useState, useEffect } from "react";
import Admin from "./features/Admin";
// import Home from "./features/home";
// import Cart from "./features/cart";

function App() {
  return (
    <div>
      <Admin />
    </div>
  );
}

export default App;
