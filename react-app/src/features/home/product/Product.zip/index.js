import React from 'react';
import Home from './features/home';
import Navbarp from './Navbarp';
import PageHeader from './PageHeader';
import ProductsStart from './ProductsStart';
import ShopDetail from './ShopDetail';


function product() {
  return (
    <div>

    <Navbarp />
    <PageHeader />
    <ProductsStart />
    <ShopDetail />
    

      
    </div>
  );
}

export default product;
