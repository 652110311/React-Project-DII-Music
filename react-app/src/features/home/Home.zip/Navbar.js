import React from "react";

function Navbar() {
  
  return (
    <div className="container-fluid mb-5">
      <div className="row border-top px-xl-5">
        <div className="col-lg-3 d-none d-lg-block">
          <a className="btn shadow-none d-flex align-items-center justify-content-between bg-primary text-white w-100" data-toggle="collapse" href="#navbar-vertical" style={{ height: '65px', marginTop: '-1px', padding: '0 30px' }}>
            <h6 className="m-0">Categories</h6>
            <i className="fa fa-angle-down text-dark"></i>
          </a>
          <nav className="collapse show navbar navbar-vertical navbar-light align-items-start p-0 border border-top-0 border-bottom-0" id="navbar-vertical">
    <div className="navbar-nav w-100 overflow-hidden" style={{ height: '410px' }}>
        <div className="nav-item dropdown">
            <a href="#" className="nav-link" data-toggle="dropdown">Bass <i className="fa fa-angle-down float-right mt-1"></i></a>
            <div className="dropdown-menu position-absolute bg-secondary border-0 rounded-0 w-100 m-0">
                <a href="" className="dropdown-item">bass1</a>
                <a href="" className="dropdown-item">bass2</a>
                <a href="" className="dropdown-item">bass3</a>
                <a href="" className="dropdown-item">bass4</a>
                <a href="" className="dropdown-item">bass5</a>
                <a href="" className="dropdown-item">bass6</a>
                <a href="" className="dropdown-item">bass7</a>
                <a href="" className="dropdown-item">bass8</a>
                <a href="" className="dropdown-item">bass9</a>
            </div>
        </div>
        <a href="#" className="nav-link" data-toggle="dropdown">Drum <i className="fa fa-angle-down float-right mt-1"></i></a>
            <div className="dropdown-menu position-absolute bg-secondary border-0 rounded-0 w-100 m-0">
                <a href="" className="dropdown-item">drum1</a>
                <a href="" className="dropdown-item">drum2</a>
                <a href="" className="dropdown-item">drum3</a>
                <a href="" className="dropdown-item">drum4</a>
                <a href="" className="dropdown-item">drum5</a>
                <a href="" className="dropdown-item">drum6</a>
                <a href="" className="dropdown-item">drum7</a>
                <a href="" className="dropdown-item">drum8</a>
                <a href="" className="dropdown-item">drum9</a>
            </div>
        <a href="#" className="nav-link" data-toggle="dropdown">Guitar<i className="fa fa-angle-down float-right mt-1"></i></a>
            <div className="dropdown-menu position-absolute bg-secondary border-0 rounded-0 w-100 m-0">
                <a href="" className="dropdown-item">guitar1</a>
                <a href="" className="dropdown-item">guitar2</a>
                <a href="" className="dropdown-item">guitar3</a>
                <a href="" className="dropdown-item">guitar4</a>
                <a href="" className="dropdown-item">guitar5</a>
                <a href="" className="dropdown-item">guitar6</a>
                <a href="" className="dropdown-item">guitar7</a>
                <a href="" className="dropdown-item">guitar8</a>
                <a href="" className="dropdown-item">guitar9</a>
            </div>
            <a href="#" className="nav-link" data-toggle="dropdown">Piano<i className="fa fa-angle-down float-right mt-1"></i></a>
            <div className="dropdown-menu position-absolute bg-secondary border-0 rounded-0 w-100 m-0">
                <a href="" className="dropdown-item">piano1</a>
                <a href="" className="dropdown-item">piano2</a>
                <a href="" className="dropdown-item">piano3</a>
                <a href="" className="dropdown-item">piano4</a>
                <a href="" className="dropdown-item">piano5</a>
                <a href="" className="dropdown-item">piano6</a>
                <a href="" className="dropdown-item">piano7</a>
                <a href="" className="dropdown-item">piano8</a>
                <a href="" className="dropdown-item">piano9</a>
            </div>
            <a href="#" className="nav-link" data-toggle="dropdown">Violin<i className="fa fa-angle-down float-right mt-1"></i></a>
            <div className="dropdown-menu position-absolute bg-secondary border-0 rounded-0 w-100 m-0">
                <a href="" className="dropdown-item">violin1</a>
                <a href="" className="dropdown-item">violin2</a>
                <a href="" className="dropdown-item">violin3</a>
                <a href="" className="dropdown-item">violin4</a>
                <a href="" className="dropdown-item">violin5</a>
                <a href="" className="dropdown-item">violin6</a>
                <a href="" className="dropdown-item">violin7</a>
                <a href="" className="dropdown-item">violin8</a>
                <a href="" className="dropdown-item">violin9</a>
            </div>
    </div>
</nav>

        </div>
        <div className="col-lg-9">
          <nav className="navbar navbar-expand-lg bg-light navbar-light py-3 py-lg-0 px-0">
          <a href="" className="text-decoration-none d-block d-lg-none">
                    <h1 className="m-0 display-5 font-weight-semi-bold"><span className="text-primary font-weight-bold border px-3 mr-1">E</span>Shopper</h1>
                </a>
                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                    <span className="navbar-toggler-icon"></span>
                </button>

                
          </nav>

          <div id="header-carousel" className="carousel slide" data-ride="carousel">
            <div className="carousel-inner">
              <div className="carousel-item active" style={{ height: '410px' }}>
                <img className="img-fluid w-100" src="" alt="" />
                <div className="carousel-caption d-flex flex-column align-items-center justify-content-center">
                  <div className="p-3" style={{ maxWidth: '700px' }}>
                    <h4 className="text-light text-uppercase font-weight-medium mb-3">WELCOME TO</h4>
                    <h3 className="display-4 text-white font-weight-semi-bold mb-4">DII MUSIC</h3>
                    <a href="" className="btn btn-light py-2 px-3">Shop Now</a>
                  </div>
                </div>
              </div>
              {/* ... */}
            </div>
            <a className="carousel-control-prev" href="#header-carousel" data-slide="prev">
              <div className="btn btn-dark" style={{ width: '45px', height: '45px' }}>
                <span className="carousel-control-prev-icon mb-n2"></span>
              </div>
            </a>
            <a className="carousel-control-next" href="#header-carousel" data-slide="next">
              <div className="btn btn-dark" style={{ width: '45px', height: '45px' }}>
                <span className="carousel-control-next-icon mb-n2"></span>
              </div>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Navbar;
