
import Topbar from './Topbar';
import Navbar from './Navbar';
import Featured from './Featured';
import Categories from './Categories';
import Product from './Product';
import Footer from './Footer';
import React, { useState } from "react";
import dataProduct from "../../app/productData";



function Home() {
    const [products, setProducts] = useState(dataProduct);
  return (
    <div>

      <Topbar />
      <Navbar />
      <Featured />
      <Categories />
      
      <ul className ="products-list">
        {products.map((product)=>(<Product key={product.id} item={product} />))}
        
      </ul>

      <Footer />
 
      
    </div>
  );
}

export default Home;
